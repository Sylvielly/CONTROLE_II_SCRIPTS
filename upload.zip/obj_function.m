function [ripple] = obj_function(x) 
global G
%%%%parameters
V_in = 20;
k_L  = 0.6666;
fs   = 50000;
L_2  = 0.0001;
DZ   = 0.6;
%%%%%%%%%%%%

%%%%variables to optimize
k = x(1);
D = x(2);
%%%%%%%%%%


%minimize
if D >= DZ
    ripple1= (V_in / (k_L*fs*L_2)) * (1-D- k_L*D);
    ripple1= abs(ripple1);

    ripple2 = (V_in / (k_L*fs*L_2)) * (k_L-k*D-k_L*k*D);
    ripple2 = abs(ripple2);
else
    ripple1= (V_in / (k_L*fs*L_2)) * (k*D)*(1-D- k_L*D);
    ripple1= abs(ripple1);
    flag=1;
    ripple2 = (V_in / (k_L*fs*L_2)) * (D/(1-(k*D)))*(k_L-k*D-k_L*k*D);
    ripple2 = abs(ripple2);
end

if ripple1 > ripple2
    ripple = ripple1;
else
    ripple = ripple2;
end

%constraints
G_aprox = (1/(1- k*D)) + (D/(1-D));

t = G/100;%tolerance
if  G_aprox >= G && G_aprox <= G+t
  c1= 0; %no violated
else
  c1= 1; %violated
end

    
h= abs(c1*(G-G_aprox))*10; % penalty function
ripple= ripple+ h;
end

