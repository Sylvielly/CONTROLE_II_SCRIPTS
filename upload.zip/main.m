clear all

global G

%Example for gain G=3

%Parameters
G=3; %gain
d = 2; % [k,D]
Max_iter = 100; %MaxIt
Part_N =20;  %%npop

l = zeros(1,d); 
u = ones(1,d);
% Optimization
[BestFitt,BestSolu]= DE(@obj_function,Part_N,d,Max_iter,l,u);

%Solutions
k = BestSolu(1);
D = BestSolu(2);

disp(['Best ripple: ', num2str(BestFitt)])
disp(['Best duty cycle: ', '  D=', num2str(BestSolu(2)),'  K=',num2str(BestSolu(1)) ])



